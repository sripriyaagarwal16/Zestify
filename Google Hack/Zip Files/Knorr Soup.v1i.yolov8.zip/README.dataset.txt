# Knorr Soup > 2024-09-05 6:20pm
https://universe.roboflow.com/my-workspace-2ihlf/knorr-soup

Provided by a Roboflow user
License: CC BY 4.0

