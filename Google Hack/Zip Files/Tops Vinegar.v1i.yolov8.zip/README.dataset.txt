# Tops Vinegar > 2024-09-07 5:40pm
https://universe.roboflow.com/my-workspace-2ihlf/tops-vinegar

Provided by a Roboflow user
License: CC BY 4.0

