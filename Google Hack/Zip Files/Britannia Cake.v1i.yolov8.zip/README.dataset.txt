# Britannia Cake > 2024-09-05 4:50pm
https://universe.roboflow.com/my-workspace-2ihlf/britannia-cake

Provided by a Roboflow user
License: CC BY 4.0

