# MDH Garam Masala > 2024-09-07 4:06pm
https://universe.roboflow.com/my-workspace-2ihlf/mdh-garam-masala

Provided by a Roboflow user
License: CC BY 4.0

