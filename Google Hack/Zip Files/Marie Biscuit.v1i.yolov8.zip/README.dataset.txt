# Marie Biscuit > 2024-09-07 8:28am
https://universe.roboflow.com/my-workspace-2ihlf/marie-biscuit

Provided by a Roboflow user
License: CC BY 4.0

