# Salted Peanuts > 2024-09-07 5:53pm
https://universe.roboflow.com/ipshita-tandon/salted-peanuts

Provided by a Roboflow user
License: CC BY 4.0

