# Chings Green Chilli Sauce > 2024-09-08 9:23pm
https://universe.roboflow.com/ipshita-tandon/chings-green-chilli-sauce

Provided by a Roboflow user
License: CC BY 4.0

