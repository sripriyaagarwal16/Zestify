# Doritos > 2024-09-06 8:53am
https://universe.roboflow.com/my-workspace-2ihlf/doritos-4pu8o

Provided by a Roboflow user
License: CC BY 4.0

