# MDH Haldi > 2024-09-07 6:04pm
https://universe.roboflow.com/ipshita-tandon/mdh-haldi

Provided by a Roboflow user
License: CC BY 4.0

