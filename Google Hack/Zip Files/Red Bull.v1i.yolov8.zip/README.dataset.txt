# Red Bull > 2024-09-08 5:25am
https://universe.roboflow.com/ipshita-tandon/red-bull-y3rsx

Provided by a Roboflow user
License: CC BY 4.0

