# Parle G > 2024-09-05 6:54pm
https://universe.roboflow.com/my-workspace-2ihlf/parle-g

Provided by a Roboflow user
License: CC BY 4.0

