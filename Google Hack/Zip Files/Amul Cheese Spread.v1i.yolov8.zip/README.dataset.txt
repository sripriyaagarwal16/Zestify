# Amul Cheese Spread > 2024-09-05 5:57pm
https://universe.roboflow.com/my-workspace-2ihlf/amul-cheese-spread

Provided by a Roboflow user
License: CC BY 4.0

