# Chings Red Chilli Sauce > 2024-09-08 5:54am
https://universe.roboflow.com/ipshita-tandon/chings-red-chilli-sauce

Provided by a Roboflow user
License: CC BY 4.0

